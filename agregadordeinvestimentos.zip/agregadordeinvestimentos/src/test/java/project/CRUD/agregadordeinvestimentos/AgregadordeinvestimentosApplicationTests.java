package project.CRUD.agregadordeinvestimentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgregadordeinvestimentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
